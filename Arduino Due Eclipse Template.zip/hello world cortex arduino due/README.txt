In order to compile the project, the symbol __SAM3X8E__ must be defined.
