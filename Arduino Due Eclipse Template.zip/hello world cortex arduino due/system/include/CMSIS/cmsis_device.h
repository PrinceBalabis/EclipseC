#ifndef _CMSIS_H_
#define _CMSIS_H_

#include "sam3x.h"

#endif // _CMSIS_H_
