/*
 * sam3x_conf.h
 *
 *  Created on: 23/lug/2014
 *      Author: andrea
 */

#ifndef SAM3X_CONF_H_
#define SAM3X_CONF_H_

#include <sam3x.h>
#define __SAM3X8E__

#endif /* SAM3X_CONF_H_ */
